jQuery(document).ready(function($){
    //массивы с ссылками на картинки(например первый массив для глаз)
    var eyesArray = ["/images/eyes1.png", "/images/eyes2.png", "/images/eyes3.png"];
    
    var noseArray = ["/images/nose1.png", "/images/nose2.png"]

    var colorArray = ["", "/images/color1.png", "/images/color2.png", "/images/color3.png"];

    var hairArray = ["/images/hair1.png", "/images/hair2.png", "/images/hair3.png", ""]

    var topArray = ["/images/top1.png", "/images/top2.png", "/images/top3.png"]

    var browsArray = ["/images/brows1.png", "/images/brows2.png", "/images/brows3.png"]

    var clothesArray = ["/images/clothes1.png", "/images/clothes2.png", "/images/clothes3.png"];
    
    //моя попытка создать функцию которая меняет цвет глаз
    var color = 0;
    function changeEyeColor(){
       if(color < 4 && color >= 0){
          //по значению переменной color поменяет ссылку на картинку в тэгах с классом image
          $(".image").attr("src", eyesArray[color]);
          color++;
       }
       else{
        color = 0; 
       }
    }
    // чета не так с вызовом (сделано частично с jquery)
    //по щелчку на кнопку с классом body_button должна вызваться функция смены глаз
    $(".body_button").click(changeEyeColor());
    }
);